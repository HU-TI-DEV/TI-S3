#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "esp_log.h"

/* Shared resource */
static int sharedCounter = 0;
/* Mutex to protect the shared resource */
static SemaphoreHandle_t counterMutex = nullptr;

class CounterTask
{
public:
    CounterTask(const char *tag,
                uint32_t periodMs,
                const char *name,
                uint32_t stackSize = 4096,
                UBaseType_t priority = tskIDLE_PRIORITY + 1)
        : tag(tag),
          delayTicks(pdMS_TO_TICKS(periodMs))
    {
        xTaskCreate(taskWrapper, name, stackSize, this, priority, nullptr);
    }

private:
    const char *tag;
    TickType_t delayTicks;

    void run()
    {
        for (;;)
        {
            ESP_LOGI(tag, "Trying to take the mutex...");
            /* Try to take the mutex */
            if (counterMutex != nullptr &&
                xSemaphoreTake(counterMutex, pdMS_TO_TICKS(20000)) == pdTRUE)
            {
                ESP_LOGI(tag, "I took the power");
                /* ---- Critical section ---- */
                sharedCounter++;
                ESP_LOGI(tag, "Counter value: %d", sharedCounter);
                /* -------------------------- */
                ESP_LOGI(tag, "I give the power to vtaskDelay");
                vTaskDelay(1000);
                ESP_LOGI(tag, "I have the power back and I release the mutex");

                xSemaphoreGive(counterMutex);
            }
            else
            {
                ESP_LOGW(tag, "Could not take mutex");
            }

            vTaskDelay(delayTicks);
        }
    }

    static void taskWrapper(void *pvParameters)
    {
        static_cast<CounterTask *>(pvParameters)->run();
    }
};

extern "C" void app_main(void)
{
    /* Create the mutex before starting tasks */
    counterMutex = xSemaphoreCreateMutex();

    if (counterMutex == nullptr)
    {
        ESP_LOGE("APP_MAIN", "Failed to create mutex");
        return;
    }

    /* Two tasks competing for the same resource */
    static CounterTask task1("TASK_1", 1500, "CounterTask1");
    static CounterTask task2("TASK_2", 1000, "CounterTask2");
}
