#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"
#include "esp_log.h"

#define BIT_0 (1 << 0)
#define BIT_4 (1 << 4)

class EventGroupTask
{
public:
    EventGroupTask(EventGroupHandle_t eventGroup,
                   uint32_t waitMs = 5000,
                   const char *name = "EventGroupTask",
                   uint32_t stackSize = 4096,
                   UBaseType_t priority = tskIDLE_PRIORITY + 1)
        : eventGroup(eventGroup),
          delayTicks(pdMS_TO_TICKS(waitMs))
    {
        xTaskCreate(taskWrapper, name, stackSize, this, priority, nullptr);
    }

private:
    EventGroupHandle_t eventGroup;
    TickType_t delayTicks;
    const char *tag = "EVENT_TASK";

    void run()
    {
        for (;;)
        {
            EventBits_t uxBits = xEventGroupWaitBits(
                eventGroup,         // The event group being tested
                BIT_0 | BIT_4,      // Bits to wait for
                pdTRUE,             // Clear bits before returning
                pdFALSE,            // Wait for either bit (not both)
                delayTicks          // Maximum wait time
            );

            // Handle the bits
            if ((uxBits & (BIT_0 | BIT_4)) == (BIT_0 | BIT_4))
            {
                ESP_LOGI(tag, "Both BIT_0 and BIT_4 were set");
            }
            else if ((uxBits & BIT_0) != 0)
            {
                ESP_LOGI(tag, "Only BIT_0 was set");
            }
            else if ((uxBits & BIT_4) != 0)
            {
                ESP_LOGI(tag, "Only BIT_4 was set");
            }
            else
            {
                ESP_LOGI(tag, "Timeout: no bits were set");
            }
        }
    }

    static void taskWrapper(void *pvParameters)
    {
        static_cast<EventGroupTask *>(pvParameters)->run();
    }
};

extern "C" void app_main(void)
{
    // Create the event group
    static EventGroupHandle_t myEventGroup = xEventGroupCreate();

    // Create the task (starts automatically)
    static EventGroupTask eventTask(myEventGroup);

    // Example: simulate setting bits
    for (;;)
    {
        ESP_LOGI("APP_MAIN","set BIT_0");
        xEventGroupSetBits(myEventGroup, BIT_0); 
        vTaskDelay(pdMS_TO_TICKS(1000));

        ESP_LOGI("APP_MAIN","set BIT_4");
        xEventGroupSetBits(myEventGroup, BIT_4); 
        vTaskDelay(pdMS_TO_TICKS(1000));

        ESP_LOGI("APP_MAIN","set BIT_0 and BIT_4");
        xEventGroupSetBits(myEventGroup, BIT_0); 
        xEventGroupSetBits(myEventGroup, BIT_4); 
        vTaskDelay(pdMS_TO_TICKS(1000));

        ESP_LOGI("APP_MAIN","set BIT_0 | BIT_4 (really at the same time)");
        xEventGroupSetBits(myEventGroup, BIT_0 | BIT_4); 
        vTaskDelay(pdMS_TO_TICKS(1000));
    }
}
