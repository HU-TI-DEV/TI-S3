# Beschrijving
Dit template is bedoeld als basis voor het programmeren van een ESP32 met FreeRTOS. Het implementeert een verzonnen systeem (bv de embedded controller van een wasmachine) en laat zien hoe je een statemachine implementeert met switch cases. Daarnaast demonstreert het een aantal simpele voorbeelden van FreeRTOS synchronisatie mechanismen.

Je kan dit template gebruiken voor het project of je individuele opdracht (in 2026 is dat een game).

Veel succes!  
@BartBozon

## Use cases of activity diagram
Niet aanwezig

## Object model
![alt text](./architecture/ObjectModel.png)

## Klasse diagram
![alt text](./architecture/ClassDiagram.png)

## STD's
![alt text](./architecture/STDMachineControl.png)

![alt text](./architecture/STDCounter.png)

