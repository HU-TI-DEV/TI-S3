#include "app/MachineControl.hpp"
#include "driver/gpio.h"
#include "esp_rom_gpio.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"
#include "esp_log.h"

static const char *TAG = "MachineControl";

MachineControl::MachineControl(uint8_t ledPinR, uint8_t ledPinG, uint8_t ledPinB,
                                           UBaseType_t priority, BaseType_t core)
    : pinLEDR(ledPinR), pinLEDG(ledPinG), pinLEDB(ledPinB),
      state(State::Ready), executingCounter(0),
      eventBitBootButton(1<<0)
{
  eventGroup = xEventGroupCreate();
  configASSERT(eventGroup!= NULL);

  dataQueue = xQueueCreate(10, sizeof(int));
  configASSERT(dataQueue != NULL);

  gpio_config_t io_conf{};
  io_conf.mode = GPIO_MODE_OUTPUT;
  io_conf.intr_type = GPIO_INTR_DISABLE;

  io_conf.pin_bit_mask = (1ULL << pinLEDR);
  gpio_config(&io_conf);
  gpio_set_level((gpio_num_t)pinLEDR, 0);

  io_conf.pin_bit_mask = (1ULL << pinLEDG);
  gpio_config(&io_conf);
  gpio_set_level((gpio_num_t)pinLEDG, 0);

  io_conf.pin_bit_mask = (1ULL << pinLEDB);
  gpio_config(&io_conf);
  gpio_set_level((gpio_num_t)pinLEDB, 0);

  xTaskCreatePinnedToCore(taskWrapper, "StateMachineTask", 2048, this, priority, &taskHandle, core);
}

void MachineControl::taskWrapper(void *arg)
{
  static_cast<MachineControl *>(arg)->runTask();
}

void MachineControl::bootButtonPressed()
{
  xEventGroupSetBits(eventGroup, eventBitBootButton);
}

void MachineControl::counterUpdated(int data)
{
  xQueueSend(dataQueue, &data, 0);
}

void MachineControl::print_all_messages_and_clear_queue()
{
  int val;
  while (xQueueReceive(dataQueue, &val, 0) == pdTRUE)
  {
    ESP_LOGI(TAG, "Processing queue data: %d", val);
  }
}

void MachineControl::setLEDColor(Color c)
{
  gpio_set_level((gpio_num_t)pinLEDR, 1);
  gpio_set_level((gpio_num_t)pinLEDG, 1);
  gpio_set_level((gpio_num_t)pinLEDB, 1);

  switch (c)
  {
  case Color::Red:
    gpio_set_level((gpio_num_t)pinLEDR, 0);
    break;
  case Color::Green:
    gpio_set_level((gpio_num_t)pinLEDG, 0);
    break;
  case Color::Blue:
    gpio_set_level((gpio_num_t)pinLEDB, 0);
    break;
  case Color::Cyan:
    gpio_set_level((gpio_num_t)pinLEDG, 0);
    gpio_set_level((gpio_num_t)pinLEDB, 0);
    break;
  case Color::Magenta:
    gpio_set_level((gpio_num_t)pinLEDR, 0);
    gpio_set_level((gpio_num_t)pinLEDB, 0);
    break;
  case Color::Yellow:
    gpio_set_level((gpio_num_t)pinLEDR, 0);
    gpio_set_level((gpio_num_t)pinLEDG, 0);
    break;
  }
}

void MachineControl::runTask()
{
  while (true)
  {
    switch (state)
    {

    case State::Ready:
      ESP_LOGI(TAG, "State is Ready");
      ESP_LOGI(TAG, "Waiting for button event...");
      setLEDColor(Color::Green);
      xEventGroupWaitBits(eventGroup, eventBitBootButton, pdTRUE, pdFALSE, portMAX_DELAY);
      state = State::Executing;
      executingCounter++;
      break;

    case State::Executing:
      ESP_LOGI(TAG, "State is Executing");
      setLEDColor(Color::Blue);
      vTaskDelay(2000 / portTICK_PERIOD_MS);
      state = (executingCounter < 3) ? State::Ready : State::Error;
      break;

    case State::Error:
      ESP_LOGI(TAG, "State is Error");
      ESP_LOGI(TAG, "Waiting for button event...");
      setLEDColor(Color::Red);
      executingCounter = 0;
      xEventGroupWaitBits(eventGroup, eventBitBootButton, pdTRUE, pdFALSE, portMAX_DELAY);
      if (uxQueueMessagesWaiting(dataQueue) > 0)
      {
        state = State::CleaningMessages;
      }
      else
      {
        state = State::NoMessages;
      }      
      break;

    case State::CleaningMessages:
      ESP_LOGI(TAG, "State is CleaningMessages");
      setLEDColor(Color::Cyan);
      print_all_messages_and_clear_queue();
      vTaskDelay(5000 / portTICK_PERIOD_MS);
      state = State::Ready;
      break;
    case State::NoMessages:
      ESP_LOGI(TAG, "State is NoMessages");
      setLEDColor(Color::Magenta);
      vTaskDelay(2000 / portTICK_PERIOD_MS);
      state = State::Ready;
      break;
    }
  }
}

