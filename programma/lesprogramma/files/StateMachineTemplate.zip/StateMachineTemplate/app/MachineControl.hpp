#pragma once

#include <stdint.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"
#include "freertos/queue.h"

/**
 * @brief MachineControl manages system state, LED feedback, and FreeRTOS task logic.
 *
 * This class encapsulates a FreeRTOS task that controls a machine state machine,
 * processes queued data messages, reacts to a boot button event, and controls RGB LED output.
 */
class MachineControl
{
public:
  /**
   * @brief High-level machine operating states.
   */
  enum class State
  {
    Ready,            ///< System is idle and ready
    Executing,        ///< System is actively processing
    Error,            ///< System is in an error state
    CleaningMessages, ///< Queue cleanup is in progress
    NoMessages        ///< Queue is empty
  };

private:
  uint8_t pinLEDR; ///< GPIO pin for red LED channel
  uint8_t pinLEDG; ///< GPIO pin for green LED channel
  uint8_t pinLEDB; ///< GPIO pin for blue LED channel

  State state; ///< Current machine state

  /**
   * @brief LED output colors for visual system feedback.
   */
  enum class Color
  {
    Red,
    Green,
    Blue,
    Cyan,
    Magenta,
    Yellow
  };

  uint32_t executingCounter; ///< Counts processed events while executing
  TaskHandle_t taskHandle;    ///< FreeRTOS task handle for control task

  EventGroupHandle_t eventGroup; ///< Event group for system signaling
  EventBits_t eventBitBootButtonPressed; ///< Event bit for boot button press event

  QueueHandle_t dataQueue;   ///< Queue storing incoming data messages
  EventBits_t queueEventBit; ///< Event bit signaling queued message activity

  /**
   * @brief Main FreeRTOS task execution loop.
   *
   * Handles machine state transitions, queue processing, and LED feedback.
   */
  void runTask();

  /**
   * @brief Static wrapper to connect FreeRTOS task entry to C++ instance method.
   *
   * @param arg Pointer to MachineControl instance.
   */
  static void taskWrapper(void *arg);

  /**
   * @brief Sets RGB LED output color.
   *
   * @param c Color enum indicating desired LED color.
   */
  void setLEDColor(Color c);

  /**
   * @brief Prints all queued messages and clears the queue.
   *
   * Used when transitioning into cleanup states.
   */
  void print_all_messages_and_clear_queue();

public:
  /**
   * @brief Constructs MachineControl and initializes task, GPIO, queue, and events.
   *
   * @param ledPinR GPIO pin number for red LED.
   * @param ledPinG GPIO pin number for green LED.
   * @param ledPinB GPIO pin number for blue LED.
   * @param priority FreeRTOS task priority (default = 2).
   * @param core CPU core assignment (default = 0).
   */
  MachineControl(uint8_t ledPinR,
                 uint8_t ledPinG,
                 uint8_t ledPinB,
                 UBaseType_t priority = 2,
                 BaseType_t core = 0);

  /**
   * @brief Signals that the boot button has been pressed.
   *
   * Typically sets an event bit to trigger system startup behavior.
   */
  void bootButtonPressed();

  /**
   * @brief Updates internal execution counter with new data.
   *
   * @param data New counter value or event data.
   */
  void counterUpdated(int data);

};
