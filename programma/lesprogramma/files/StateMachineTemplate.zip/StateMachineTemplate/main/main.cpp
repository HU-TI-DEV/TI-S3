#include "app/MachineControl.hpp"
#include "components/Button.hpp"
#include "components/Counter.hpp"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

constexpr uint8_t kPinBtn = 0;
constexpr uint8_t kPinLedR = 4;
constexpr uint8_t kPinLedG = 16;
constexpr uint8_t kPinLedB = 17;

constexpr EventBits_t BootButton = (1 << 0);

extern "C" void app_main()
{

  // Create state machine task (internally creates EventGroup + Queue)
  MachineControl machineControl(kPinLedR, kPinLedG, kPinLedB, BootButton);
  vTaskDelay(pdMS_TO_TICKS(100));
  // machineControl must be created before Button and Sender to ensure pointer is valid

  // Create button task and link it to the state machine
  Button btnInput("InputButton", kPinBtn, machineControl);

  // Create a Counter to send data to state machine
  Counter counter(machineControl);

  // main does nothing
  while (true)
  {
    vTaskDelay(pdMS_TO_TICKS(1000));
  }
}
