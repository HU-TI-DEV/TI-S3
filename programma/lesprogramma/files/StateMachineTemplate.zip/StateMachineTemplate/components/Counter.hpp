#pragma once

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

class MachineControl;

/**
 * @brief Counter generates and sends periodic counter updates to MachineControl.
 *
 * This class encapsulates a FreeRTOS task that runs a small state machine.
 * It periodically increments a counter value and sends updates to the
 * MachineControl instance.
 */
class Counter
{
public:
    /**
     * @brief Internal state machine states for counter behavior.
     */
    enum class State
    {
        IncreaseCounter, ///< Increment the counter value
        SendCounter      ///< Send the counter value to MachineControl
    };

    /**
     * @brief Constructs Counter and starts the FreeRTOS task.
     *
     * @param mc Reference to the MachineControl instance that receives counter updates.
     */
    Counter(MachineControl &mc); // Constructor starts periodic task

private:
    MachineControl &machineControl; ///< Reference to machine controller target
    TaskHandle_t taskHandle;         ///< FreeRTOS task handle for counter task
    State state;                     ///< Current counter state machine state

    /**
     * @brief Main FreeRTOS task execution loop.
     *
     * Runs the counter state machine, updates values, and sends messages
     * to MachineControl at periodic intervals.
     */
    void runTask();

    /**
     * @brief Static wrapper to connect FreeRTOS task entry to C++ instance method.
     *
     * @param arg Pointer to Counter instance.
     */
    static void taskWrapper(void *arg); // FreeRTOS task wrapper
};
