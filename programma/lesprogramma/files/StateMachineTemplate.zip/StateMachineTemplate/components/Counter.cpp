#include "Counter.hpp"
#include "app/MachineControl.hpp"
#include "esp_log.h"

// Enable (1) or disable (0) logging for this module
#define kEnableLog 0

#if kEnableLog
  static const char *TAG = "Counter";
  #define QS_LOGI(tag, fmt, ...) ESP_LOGI(tag, fmt, ##__VA_ARGS__)
#else
  #define QS_LOGI(tag, fmt, ...) ((void)0)
#endif


Counter::Counter(MachineControl& mc) : machineControl(mc), state(State::IncreaseCounter)
{
    // Start the FreeRTOS task for periodic sending
    xTaskCreatePinnedToCore(taskWrapper, "CounterTask", 2048, this, 1, &taskHandle, 0);
}

void Counter::taskWrapper(void *arg)
{
    Counter *instance = static_cast<Counter *>(arg);
    instance->runTask();
}

void Counter::runTask()
{
    int counter = 0;
    while (true)
    {
        switch (state)
        {
        case State::IncreaseCounter:
            QS_LOGI(TAG, "State is IncreaseCounter");
            counter++;
            if (counter % 5 == 0) // Send every 5th count
            {
                state = State::SendCounter;
            }
            vTaskDelay(pdMS_TO_TICKS(5000)); // send every 5 seconds
            break;
        case State::SendCounter:
            QS_LOGI(TAG, "Sending data");
            machineControl.counterUpdated(counter);
            state = State::IncreaseCounter;
            break;
        }
    }
}
