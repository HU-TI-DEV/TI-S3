#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"

class LogTask
{
public:
    LogTask(const char *tag, uint32_t periodMs, const char *name = "LogTask",
            uint32_t stackSize = 4096, UBaseType_t priority = tskIDLE_PRIORITY + 1)
        : tag(tag), delayTicks(pdMS_TO_TICKS(periodMs))
    {
        xTaskCreate(taskWrapper, name, stackSize, this, priority, nullptr);         
        // Start the task immediately in constructor
    }
private:
    const char *tag;
    TickType_t delayTicks;
    void run()
    {
        for (;;)
        {
            ESP_LOGI(tag, "Hello from FreeRTOS class task");
            vTaskDelay(delayTicks);
        }
    }
    static void taskWrapper(void *pvParameters)
    {
        static_cast<LogTask *>(pvParameters)->run();
    }
};

extern "C" void app_main(void)
{
    static LogTask logger1("LOG_TASK_1", 500);
    static LogTask logger2("LOG_TASK_2", 700);
}


