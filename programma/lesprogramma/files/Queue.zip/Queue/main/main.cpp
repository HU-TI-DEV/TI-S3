#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "esp_log.h"
#include <cstring>

struct AMessage
{
    char ucMessageID;
    char ucData[20];
};

class ProducerConsumer
{
public:
    ProducerConsumer(const char *tag = "QUEUE_TASK",
                     uint32_t queueLength = 10,
                     uint32_t stackSize = 4096,
                     UBaseType_t priority = tskIDLE_PRIORITY + 1)
        : tag(tag)
    {
        // Initialize message
        message.ucMessageID = 0xAB;
        memset(message.ucData, 0x12, sizeof(message.ucData));

        // Create queue
        structQueue = xQueueCreate(queueLength, sizeof(AMessage));
        if (!structQueue)
        {
            ESP_LOGE(tag, "Failed to create struct queue!");
            return;
        }

        // Start producer and consumer tasks
        xTaskCreate(producerWrapper, "ProducerTask", stackSize, this, priority, nullptr);
        xTaskCreate(consumerWrapper, "ConsumerTask", stackSize, this, priority, nullptr);
    }

private:
    const char *tag;
    AMessage message;
    QueueHandle_t structQueue = nullptr;

    // --- Producer task ---
    void producerTask()
    {
        for (;;)
        {
            if (xQueueSend(structQueue, &message, 0) == pdPASS)
            {
                ESP_LOGI(tag, "Produced message ID=0x%X", message.ucMessageID);
                message.ucMessageID++; // increment ID for demonstration
            }
            else
            {
                ESP_LOGW(tag, "Queue full, message not sent");
            }
            vTaskDelay(pdMS_TO_TICKS(500)); // produce every 500ms
        }
    }

    // --- Consumer task ---
    void consumerTask()
    {
        AMessage received;
        for (;;)
        {
            if (xQueueReceive(structQueue, &received, portMAX_DELAY) == pdPASS)
            {
                ESP_LOGI(tag, "Consumed message ID=0x%X", received.ucMessageID);
            }
        }
    }

    // --- Static wrappers for FreeRTOS ---
    static void producerWrapper(void *pvParameters)
    {
        static_cast<ProducerConsumer *>(pvParameters)->producerTask();
    }

    static void consumerWrapper(void *pvParameters)
    {
        static_cast<ProducerConsumer *>(pvParameters)->consumerTask();
    }
};

extern "C" void app_main(void)
{
    static ProducerConsumer queueSystem;
    // Constructor automatically starts producer and consumer tasks
}
