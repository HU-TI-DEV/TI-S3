#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/timers.h"
#include "esp_log.h"

class TimerDemo
{
public:
    TimerDemo(const char *tag = "TIMER_TASK",
              uint32_t periodMs = 2000,
              uint32_t stackSize = 4096,
              UBaseType_t priority = tskIDLE_PRIORITY + 1)
        : tag(tag),
          periodTicks(pdMS_TO_TICKS(periodMs))
    {
        // Create software timer
        timerHandle = xTimerCreate(
            "DemoTimer",          // Timer name
            periodTicks,          // Period in ticks
            pdTRUE,               // Auto-reload timer
            this,                 // Timer ID (pass class instance)
            timerCallbackWrapper  // Callback function
        );

        if (!timerHandle)
        {
            ESP_LOGE(tag, "Failed to create timer!");
            return;
        }

        // Start timer
        xTimerStart(timerHandle, 0);

        // Start monitor task
        xTaskCreate(taskWrapper, "TimerMonitorTask", stackSize, this, priority, nullptr);
    }

private:
    const char *tag;
    TickType_t periodTicks;
    TimerHandle_t timerHandle = nullptr;
    uint32_t callbackCounter = 0;

    // --- Timer callback ---
    void onTimer()
    {
        callbackCounter++;
        ESP_LOGI(tag, "Timer callback fired! Count=%lu", callbackCounter);
    }

    // --- Monitor task ---
    void monitorTask()
    {
        for (;;)
        {
            ESP_LOGI(tag, "Monitor running... Timer count=%lu", callbackCounter);
            vTaskDelay(pdMS_TO_TICKS(3000));
        }
    }

    // --- Static wrappers ---
    static void timerCallbackWrapper(TimerHandle_t xTimer)
    {
        auto *self = static_cast<TimerDemo *>(pvTimerGetTimerID(xTimer));
        self->onTimer();
    }

    static void taskWrapper(void *pvParameters)
    {
        static_cast<TimerDemo *>(pvParameters)->monitorTask();
    }
};

extern "C" void app_main(void)
{
    static TimerDemo timerDemo;
    // Constructor automatically starts timer + monitor task
}
