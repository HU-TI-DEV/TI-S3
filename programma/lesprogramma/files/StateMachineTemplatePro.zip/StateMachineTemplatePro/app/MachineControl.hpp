#pragma once

#include <stdint.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"
#include "freertos/queue.h"

class Counter;

/**
 * @brief MachineControl manages system state, LED feedback, and FreeRTOS task logic.
 *
 * This class encapsulates a FreeRTOS task that controls a machine state machine,
 * processes queued data messages, reacts to a boot button event, and controls RGB LED output.
 */
class MachineControl
{
public:
  /**
   * @brief High-level machine operating states.
   */
  enum class State
  {
    StateA, StateB, StateC, StateD, StateE, StateF, StateG, StateH
  };

private:
  uint8_t pinLEDR; ///< GPIO pin for red LED channel
  uint8_t pinLEDG; ///< GPIO pin for green LED channel
  uint8_t pinLEDB; ///< GPIO pin for blue LED channel

  State state; ///< Current machine state

  /**
   * @brief LED output colors for visual system feedback.
   */
  enum class Color
  {
    Red,
    Green,
    Blue,
    Cyan,
    Magenta,
    Yellow
  };
  uint32_t executingCounter; ///< Counts processed events while executing
  TaskHandle_t taskHandle;   ///< FreeRTOS task handle for control task

  EventGroupHandle_t eventGroup;         ///< Event group for system signaling
  EventBits_t eventBitButton1Pressed; ///< Event bit for button 1 press event
  EventBits_t eventBitButton2Pressed; ///< Event bit for button 2 press event
  Counter &counterObject; ///< Reference to the Counter instance

  EventBits_t uxBits;  ///< Variable to hold event bits returned from waits
 
  /**
   * @brief Main FreeRTOS task execution loop.
   *
   * Handles machine state transitions, queue processing, and LED feedback.
   */
  void runTask();

  /**
   * @brief Static wrapper to connect FreeRTOS task entry to C++ instance method.
   *
   * @param arg Pointer to MachineControl instance.
   */
  static void taskWrapper(void *arg);

  /**
   * @brief Sets RGB LED output color.
   *
   * @param c Color enum indicating desired LED color.
   */

  void setLEDColor(Color c);

public:
  /**
   * @brief Constructs MachineControl and initializes task, GPIO, queue, and events.
   *
   * @param ledPinR GPIO pin number for red LED.
   * @param ledPinG GPIO pin number for green LED.
   * @param ledPinB GPIO pin number for blue LED.
   * @param priority FreeRTOS task priority (default = 2).
   * @param core CPU core assignment (default = 0).
   */
  MachineControl(uint8_t ledPinR,
                 uint8_t ledPinG,
                 uint8_t ledPinB,
                 Counter &counterObject,
                 UBaseType_t priority = 2,
                 BaseType_t core = 0); // Constructor initializes system and starts task

  /**
   * @brief Signals that the first button has been pressed.
   *
   * Typically sets an event bit to trigger system startup behavior.
   */
  void button1Pressed();

  /**
   * @brief Signals that the second button has been pressed.
   *
   * Typically sets an event bit to trigger system startup behavior.
   */
  void button2Pressed();

};
