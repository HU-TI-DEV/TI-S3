#include "app/MachineControl.hpp"
#include "components/Counter.hpp"
#include "driver/gpio.h"
#include "esp_rom_gpio.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"
#include "esp_log.h"

static const char *TAG = "MachineControl";

MachineControl::MachineControl(uint8_t ledPinR, uint8_t ledPinG, uint8_t ledPinB, Counter &counterObject,
                               UBaseType_t priority, BaseType_t core)
    : pinLEDR(ledPinR), pinLEDG(ledPinG), pinLEDB(ledPinB),
      state(State::StateA), executingCounter(0),
      eventBitButton1Pressed(1 << 0), eventBitButton2Pressed(1 << 1), counterObject(counterObject)  
{
  eventGroup = xEventGroupCreate();
  configASSERT(eventGroup != NULL);

  gpio_config_t io_conf{};
  io_conf.mode = GPIO_MODE_OUTPUT;
  io_conf.intr_type = GPIO_INTR_DISABLE;

  io_conf.pin_bit_mask = (1ULL << pinLEDR);
  gpio_config(&io_conf);
  gpio_set_level((gpio_num_t)pinLEDR, 0);

  io_conf.pin_bit_mask = (1ULL << pinLEDG);
  gpio_config(&io_conf);
  gpio_set_level((gpio_num_t)pinLEDG, 0);

  io_conf.pin_bit_mask = (1ULL << pinLEDB);
  gpio_config(&io_conf);
  gpio_set_level((gpio_num_t)pinLEDB, 0);

  xTaskCreatePinnedToCore(taskWrapper, "StateMachineTask", 2048, this, priority, &taskHandle, core);
}

void MachineControl::taskWrapper(void *arg)
{
  static_cast<MachineControl *>(arg)->runTask();
}

void MachineControl::button1Pressed()
{
  xEventGroupSetBits(eventGroup, eventBitButton1Pressed);
}

void MachineControl::button2Pressed()
{
  xEventGroupSetBits(eventGroup, eventBitButton2Pressed);
}

void MachineControl::setLEDColor(Color c)
{
  gpio_set_level((gpio_num_t)pinLEDR, 1);
  gpio_set_level((gpio_num_t)pinLEDG, 1);
  gpio_set_level((gpio_num_t)pinLEDB, 1);

  switch (c)
  {
  case Color::Red:
    gpio_set_level((gpio_num_t)pinLEDR, 0);
    break;
  case Color::Green:
    gpio_set_level((gpio_num_t)pinLEDG, 0);
    break;
  case Color::Blue:
    gpio_set_level((gpio_num_t)pinLEDB, 0);
    break;
  case Color::Cyan:
    gpio_set_level((gpio_num_t)pinLEDG, 0);
    gpio_set_level((gpio_num_t)pinLEDB, 0);
    break;
  case Color::Magenta:
    gpio_set_level((gpio_num_t)pinLEDR, 0);
    gpio_set_level((gpio_num_t)pinLEDB, 0);
    break;
  case Color::Yellow:
    gpio_set_level((gpio_num_t)pinLEDR, 0);
    gpio_set_level((gpio_num_t)pinLEDG, 0);
    break;
  }
}

void MachineControl::runTask()
{
  while (true)
  {
    switch (state)
    {

    case State::StateA:
      ESP_LOGI(TAG, "State is StateA");
      ESP_LOGI(TAG, "Waiting for either button1 or button2...");
      setLEDColor(Color::Green);
      xEventGroupWaitBits(eventGroup, eventBitButton1Pressed | eventBitButton2Pressed, pdTRUE, pdFALSE, portMAX_DELAY);
      state = State::StateB;
      break;

    case State::StateB:
      ESP_LOGI(TAG, "State is StateB");
      ESP_LOGI(TAG, "Waiting for button1 AND button2...");
      setLEDColor(Color::Blue);
      xEventGroupWaitBits(eventGroup, eventBitButton1Pressed | eventBitButton2Pressed, pdTRUE, pdTRUE, portMAX_DELAY);
      state = State::StateC;
      break;

    case State::StateC:
      ESP_LOGI(TAG, "State is StateC");
      ESP_LOGI(TAG, "Waiting for button1 -> jump to StateD or button2 -> jump to StateE...");
      setLEDColor(Color::Red);
      uxBits = xEventGroupWaitBits(eventGroup, eventBitButton1Pressed | eventBitButton2Pressed, pdTRUE, pdFALSE, portMAX_DELAY);
      if ((uxBits & eventBitButton1Pressed) != 0)
      {
        state = State::StateD;
      }
      else if ((uxBits & eventBitButton2Pressed) != 0)
      {
        state = State::StateE;
      }
      break;

    case State::StateD:
      ESP_LOGI(TAG, "State is StateD");
      setLEDColor(Color::Cyan);
      vTaskDelay(1000 / portTICK_PERIOD_MS);
      state = State::StateF;
      executingCounter = 0;
      break;

    case State::StateE:
      ESP_LOGI(TAG, "State is StateE");
      setLEDColor(Color::Magenta);
      vTaskDelay(5000 / portTICK_PERIOD_MS);
      state = State::StateA;
      break;

    case State::StateF:
      ESP_LOGI(TAG, "State is StateF");
      setLEDColor(Color::Yellow);
      executingCounter++;
      ESP_LOGI(TAG, "Incrementing executingCounter to %d",(int) executingCounter);
      xEventGroupWaitBits(eventGroup, eventBitButton1Pressed, pdTRUE, pdFALSE, portMAX_DELAY);
      if (executingCounter < 3)
      {
        state = State::StateF;
      }
      else
      {
        state = State::StateG;
      }
      break;

    case State::StateG:
      ESP_LOGI(TAG, "State is StateG");
      setLEDColor(Color::Magenta);
      do
      {
        xEventGroupWaitBits(eventGroup, eventBitButton1Pressed, pdTRUE, pdFALSE, portMAX_DELAY);
        ESP_LOGI(TAG, "Button1 pressed in StateG, waiting for counterValue > 5");
     } while (counterObject.getCounterValue() < 6); // Exit loop when counter value is 6 or more
      state = State::StateH;
      break;

    case State::StateH:
      ESP_LOGI(TAG, "State is StateH");
      setLEDColor(Color::Yellow);
      vTaskDelay(5000 / portTICK_PERIOD_MS);
      state = State::StateA;
      break;
    }
  }
}
