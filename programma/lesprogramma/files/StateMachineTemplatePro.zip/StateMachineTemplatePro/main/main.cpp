#include "app/MachineControl.hpp"
#include "components/Button.hpp"
#include "components/Counter.hpp"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

constexpr uint8_t kPinBtn = 0;
constexpr uint8_t kPinLedR = 4;
constexpr uint8_t kPinLedG = 16;
constexpr uint8_t kPinLedB = 17;

extern "C" void app_main()
{

  Counter counter;

  vTaskDelay(pdMS_TO_TICKS(100));

  // Create state machine task (internally creates EventGroup and initializes GPIO)
  MachineControl machineControl(kPinLedR, kPinLedG, kPinLedB, counter);

  // Create button task and link it to the state machine
  Button btnInput("InputButton", kPinBtn, machineControl);

  // main does nothing
  while (true)
  {
    vTaskDelay(pdMS_TO_TICKS(1000));
  }
}
