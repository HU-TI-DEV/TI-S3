#include "Button.hpp"
#include "app/MachineControl.hpp"
#include "driver/gpio.h"
#include "esp_rom_gpio.h"
#include "esp_log.h"

static const char *TAG = "Button";

Button::Button(const char *name, uint8_t pin,
               MachineControl &mc,
               bool logic, UBaseType_t priority, BaseType_t core)
    : buttonName(name), pinButton(pin), bPositiveLogic(logic),
      machineControl(mc)
{
  esp_rom_gpio_pad_select_gpio(pinButton);
  gpio_reset_pin((gpio_num_t)pinButton);
  gpio_set_direction((gpio_num_t)pinButton, GPIO_MODE_INPUT);

  xTaskCreatePinnedToCore(taskWrapper, name, 2048, this, priority, &taskHandle, core);
}

void Button::setButtonName(const char *name) { buttonName = name; }
const char *Button::getButtonName() { return buttonName; }

bool Button::isPressed()
{
  bool level = !!gpio_get_level((gpio_num_t)pinButton);
  return (level == bPositiveLogic);
}

void Button::taskWrapper(void *arg)
{
  Button *instance = static_cast<Button *>(arg);
  instance->runTask();
}

void Button::runTask()
{
  while (true)
  {
    machineControl.button1Pressed();
    ESP_LOGI(TAG, "Button1 pressed!");
    vTaskDelay(pdMS_TO_TICKS(3000));
    machineControl.button2Pressed();
    ESP_LOGI(TAG, "Button2 pressed!");
    vTaskDelay(pdMS_TO_TICKS(3000));
    machineControl.button1Pressed();
    ESP_LOGI(TAG, "Button1 pressed!");
    vTaskDelay(pdMS_TO_TICKS(2000));
    machineControl.button2Pressed();
    ESP_LOGI(TAG, "Button2 pressed!");
    vTaskDelay(pdMS_TO_TICKS(1000));
  }
}
