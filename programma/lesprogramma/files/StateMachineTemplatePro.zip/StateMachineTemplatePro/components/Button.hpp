#pragma once

#include <stdint.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

class MachineControl;

/**
 * @brief Button handles GPIO input and notifies MachineControl of button events.
 *
 * It SIMULATES button presses for demonstration purposes.
 *
 */

class Button
{
private:
  const char* buttonName; ///< Human-readable name for debugging/logging
  uint8_t pinButton;      ///< GPIO pin connected to the button
  bool bPositiveLogic;    ///< Button logic mode (true = active-high, false = active-low)
  TaskHandle_t taskHandle; ///< FreeRTOS task handle for button task
  MachineControl &machineControl; ///< Reference to system controller

  /**
   * @brief Main FreeRTOS task loop for button monitoring.
   *
   * Continuously checks button state and triggers MachineControl when pressed.
   */
  void runTask();

  /**
   * @brief Static wrapper to link FreeRTOS task entry to C++ instance method.
   *
   * @param arg Pointer to Button instance.
   */
  static void taskWrapper(void* arg);

public:
  /**
   * @brief Constructs Button and starts the FreeRTOS monitoring task.
   *
   * @param name Human-readable button name.
   * @param pin GPIO pin number connected to the button.
   * @param mc Reference to MachineControl for event signaling.
   * @param logic Button logic mode (true = active-high, false = active-low).
   * @param priority FreeRTOS task priority (default = 1).
   * @param core CPU core assignment (default = 0).
   */
  Button(const char* name,
         uint8_t pin,
         MachineControl &mc,
         bool logic = false,
         UBaseType_t priority = 1,
         BaseType_t core = 0);

  /**
   * @brief Sets a new name for the button (for logging/debugging).
   *
   * @param name New button name string.
   */
  void setButtonName(const char* name);

  /**
   * @brief Returns the current button name.
   *
   * @return const char* Button name string.
   */
  const char* getButtonName();

  /**
   * @brief Reads and returns the current button pressed state.
   *
   * Applies configured logic inversion before returning.
   *
   * @return true If button is considered pressed.
   * @return false If button is not pressed.
   */
  bool isPressed();
};
